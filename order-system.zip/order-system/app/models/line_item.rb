# frozen_string_literal: true

class LineItem < ApplicationRecord
  belongs_to :order

  validates :quantity, presence: true
  validates :tax, presence: true
  validates :amount, presence: true
  validates :total, presence: true
  validates :subtotal, presence: true
end
