# frozen_string_literal: true

class Order < ApplicationRecord
  validates :subtotal, presence: true
  validates :tax, presence: true
  validates :total, presence: true

  has_many :line_items
  accepts_nested_attributes_for :line_items
end
