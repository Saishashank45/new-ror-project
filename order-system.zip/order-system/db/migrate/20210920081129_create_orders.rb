# frozen_string_literal: true

class CreateOrders < ActiveRecord::Migration[5.2]
  def change
    create_table :orders do |t|
      t.decimal :subtotal, null: false
      t.decimal :tax, null: false
      t.decimal :total, null: false

      t.timestamps
    end
  end
end
